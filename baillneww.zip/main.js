// main.js

const { makeWASocket } = require('@whiskeysockets/baileys');
const { useSingleFileAuthState } = require('@whiskeysockets/baileys');
const P = require('pino');
const path = require('path');

// Config & Logger
const config = require('./config');
const { logger } = require('./lib/logger');
const { sessionState, saveState } = require('./lib/session');
const { msgHandler } = require('./lib/msgHandler');
const commandParser = require('./Handler/commandParser');

// Telegram (aktifkan kalau ingin dual bot)
require('./telegram'); 

// Init WhatsApp
const startSock = async () => {
    const { state, saveCreds } = useSingleFileAuthState('./session.json');
    
    const sock = makeWASocket({
        auth: state,
        logger: P({ level: 'silent' }),
        printQRInTerminal: true,
        browser: ['baillneww', 'Chrome', '1.0.0']
    });

    // Event listeners
    sock.ev.on('creds.update', saveCreds);
    
    sock.ev.on('messages.upsert', async ({ messages, type }) => {
        if (type !== 'notify') return;
        const m = messages[0];
        if (!m.message || m.key.fromMe) return;

        try {
            await msgHandler(sock, m); // Handler utama
        } catch (err) {
            logger.error('Message Handler Error:', err);
        }
    });
};

startSock();