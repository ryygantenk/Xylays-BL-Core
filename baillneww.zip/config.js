module.exports = {
  botName: "curseryy",
  ownerName: "Conquers",
  ownerNumber: ["6288287577173@s.whatsapp.net"], // ganti dengan nomor kamu
  sessionFolder: "./session",
  autoRead: true,
  autoTyping: false,
  prefix: ["/", "!", "."],
  api: {
    caliph: "https://caliphapi.xyz",
    btch: "https://btch-api.xyz",
    // Tambahkan API lain jika perlu
  },
  github: {
    username: "ryygantenk",
    repo: "Xylays-BL-Core"
  },
  timezone: "Asia/Jakarta"
}